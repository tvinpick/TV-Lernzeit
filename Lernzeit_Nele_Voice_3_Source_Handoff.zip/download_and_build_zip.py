#!/usr/bin/env python3
"""Download 45 already-synthesized HeyGen audio assets and make a Godot WAV ZIP."""
from pathlib import Path
import csv, json, shutil, subprocess, tempfile, urllib.request, wave, zipfile, hashlib

HERE=Path(__file__).resolve().parent
rows=json.loads((HERE/'audio_sources.json').read_text('utf-8'))
assert len(rows)==45 and len({r['file'] for r in rows})==45
assert shutil.which('ffmpeg') and shutil.which('ffprobe'), 'Install FFmpeg first'

def run(*cmd):
    return subprocess.run(cmd,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True).stdout

with tempfile.TemporaryDirectory(prefix='lernzeit_nele_') as tmpdir:
    tmp=Path(tmpdir);original=tmp/'original';audio=tmp/'WAV';original.mkdir();audio.mkdir()
    durations={}
    for i,r in enumerate(rows,1):
        fn=r['file']
        raw=original/fn
        req=urllib.request.Request(r['audio_url'],headers={'User-Agent':'Mozilla/5.0 (Lernzeit-Audio-Pack)'})
        with urllib.request.urlopen(req,timeout=45) as response:
            content=response.read()
        if len(content)<1000: raise ValueError(f'Suspiciously short download: {fn} ({len(content)} bytes)')
        raw.write_bytes(content)
        dest=audio/fn
        run('ffmpeg','-hide_banner','-nostdin','-loglevel','error','-y','-i',str(raw),'-ar','44100','-ac','1','-c:a','pcm_s16le',str(dest))
        with wave.open(str(dest),'rb') as w:
            assert w.getframerate()==44100 and w.getnchannels()==1 and w.getsampwidth()==2, fn
            durations[fn]=w.getnframes()/w.getframerate()
        print(f'{i:02d}/45: {fn}: {durations[fn]:.3f}s')
    out=HERE/'Lernzeit_Nele_Voice_3_WAV.zip'
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for r in rows:z.write(audio/r['file'],r['file'])
        lines=['file\ttext\tduration_seconds']+[f"{r['file']}\t{r['text']}\t{durations[r['file']]:.3f}" for r in rows]
        z.writestr('phrases.tsv','\n'.join(lines)+'\n')
        z.writestr('README.txt','45 individual German Nele voice lines for Lernzeit. PCM16 / mono / 44100 Hz. Speed unchanged. Recheck pronunciation before release.\n')
    with zipfile.ZipFile(out) as z:
        assert len([n for n in z.namelist() if n.endswith('.wav')])==45
        assert z.testzip() is None
    print(f'COMPLETE: {out} ({out.stat().st_size} bytes)')
