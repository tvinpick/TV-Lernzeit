# Lernzeit - Nele Voice 3 source handoff (45 audio clips)

IMPORTANT: This archive contains the real HeyGen synthesis source URLs and metadata, not playable WAV files. The host could not retrieve the WAV bytes. Do NOT treat this ZIP as ready-to-import Godot assets.

Voice: HeyGen public instant voice "Nele - Friendly & Natural", de-DE.
Every one of the 45 utterances was submitted once and returned a WAV URL and duration. Audio has NOT been listened to and cannot be certified for pronunciation or clipping.

The original request requires PCM 16-bit mono 44100 Hz, speed 0.9 at synthesis, with no extra slowdown. The HeyGen instant-voice speech tool does not support speaking-speed control (the speed argument is ignored for instant voices). Generation therefore used the default speed; no additional time stretching was performed. The downloader converts FORMAT ONLY, preserving tempo and pitch.

Run on a system that has Internet access, Python 3.9+ and FFmpeg/FFprobe in PATH:
  python download_and_build_zip.py

The script will download every verified URL to a temporary folder, convert to standard PCM16/44100 Hz/mono without speed modification, measure final duration using ffprobe, and create:
  Lernzeit_Nele_Voice_3_WAV.zip
containing 45 WAV files and an updated phrases.tsv. It fails with an error if a source URL is expired, unreachable, or not valid audio. On failure, use a newly generated speech URL rather than substituting silent clips.

For two-part speech, the source ellipsis represents a runtime placeholder (not spoken). The audio texts are exactly:
 - tip_de_find: 'Schau genau auf die Form von'
 - game_target_a: 'Lass alle Ballons mit'
 - game_target_b: 'platzen!'
Godot should assemble target_a + selected number/letter + target_b with appropriate gaps.

This is NOT a replacement for the actual completed WAV bundle requested by the user. It is an honest transfer path for the completed HeyGen synthesis work.
