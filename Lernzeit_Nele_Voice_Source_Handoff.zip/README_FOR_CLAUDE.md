# Lernzeit — Nele (de-DE) / 109 real synthesized recordings

The HeyGen text-to-speech jobs have ALREADY been executed: one verified
`audio_url` from HeyGen per phrase is recorded in `audio_sources.tsv`.
**This handoff ZIP contains the source URLs, NOT downloaded WAV binaries.**
It does not create new audio and does not require a HeyGen API key.

## To produce the ready-to-import Godot WAV pack

Use Claude Code in an environment with HTTPS internet access and Python 3.
Install FFmpeg if unavailable (`sudo apt-get install -y ffmpeg`) and run:

```bash
python3 download_and_build_zip.py
```

The script downloads each actual Nele WAV and validates the RIFF/WAVE header,
then normalizes/exports PCM signed 16-bit, mono, 44100 Hz, fixed playback speed
0.9 (FFmpeg `atempo`, preserves pitch), with conservative leading/trailing
silence trimming and -20 LUFS loudness target.

On success:
- `Game_Assets/Audio/*.wav` — 109 processed files
- `phrases.tsv` — accurate processed durations
- `Lernzeit_Nele_109_WAV_for_Godot.zip` — complete Godot-ready pack

Source WAVs are kept separately under `work_original_wavs/` for resuming.
Do not resynthesize on a failed download: check URL access or expiry instead.

## Categories

- `g_prompt_*` / `shape_*` — Logik instructions and shapes
- `le_prompt_*` — reading instructions
- `satz_s01..s30` — 30 short reading sentences
- `text_t01..t08` — 8 short stories plus their questions
- `ta_prompt`, `ta_01..ta_30` — math word problems
- `word_*` — 29 vocabulary items

In Lesen, do not play reading sentences BEFORE the child's attempt;
play only AFTER the correct answer (per TASK_ASTRA.md).

## Limitations / review

The audio was generated with the selected HeyGen public voice
`Nele - Friendly & Natural` (voice_id `194c5c7896e849139df58b34b05b6a7c`).
No local listening verification was possible in the source environment:
check pronunciation and intelligibility in the finished pack.
External source links might expire. The script does not require credentials
and will report any download error rather than silently substituting audio.
