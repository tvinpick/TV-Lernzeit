#!/usr/bin/env python3
"""Download previously synthesized HeyGen Nele recordings; convert and archive for Godot.

This script DOES NOT call the HeyGen synthesis API or spend synthesis credits.
Run where HTTPS to resource2.heygen.ai and ffmpeg/ffprobe are available.
"""
import csv
import json
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCES = ROOT / 'audio_sources.tsv'
STAGING = ROOT / 'work_original_wavs'
OUTPUT = ROOT / 'Game_Assets' / 'Audio'
OUTPUT_ZIP = ROOT / 'Lernzeit_Nele_109_WAV_for_Godot.zip'

def run(command):
    return subprocess.run(command, check=True, capture_output=True, text=True)

def download(url, target):
    if target.exists() and target.stat().st_size > 1024 and target.read_bytes()[:4] == b'RIFF':
        return
    request = urllib.request.Request(url, headers={'User-Agent': 'Lernzeit-Audio-Asset-Downloader/1.0'})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=40) as response:
                data = response.read()
            if len(data) < 1024 or data[:4] != b'RIFF' or data[8:12] != b'WAVE':
                raise ValueError('HeyGen response is not a complete WAV file')
            target.write_bytes(data)
            return
        except Exception:
            if attempt == 2:
                raise
            time.sleep(1 + attempt)

def convert(source, target):
    # Keep all pauses *inside* the spoken phrase. Trim only quiet tails.
    af = (
        'silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.07,'
        'areverse,'
        'silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.10,'
        'areverse,'
        'atempo=0.9,'
        'loudnorm=I=-20:TP=-2:LRA=11'
    )
    cmd = ['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(source),
           '-vn','-af',af,'-ac','1','-ar','44100','-c:a','pcm_s16le',str(target)]
    run(cmd)
    with target.open('rb') as f:
        if f.read(4) != b'RIFF':
            raise ValueError(f'Output not a WAV: {target.name}')
    d = json.loads(run(['ffprobe','-v','error','-show_entries','format=duration',
                        '-of','json',str(target)]).stdout)
    return float(d['format']['duration'])

def main():
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        sys.exit('Install ffmpeg and ffprobe first (e.g. apt-get install ffmpeg).')
    with SOURCES.open(encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f, delimiter='\t'))
    if len(rows) != 109 or len({r['file'] for r in rows}) != 109:
        sys.exit('Expected 109 unique recordings in audio_sources.tsv.')
    STAGING.mkdir(exist_ok=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    durations=[]
    for i,r in enumerate(rows,1):
        name=r['file']
        if name != Path(name).name or not name.endswith('.wav'):
            sys.exit('Unsafe filename in audio_sources.tsv: ' + name)
        original=STAGING/name
        target=OUTPUT/name
        try:
            download(r['heygen_wav_url'], original)
            duration=convert(original,target)
        except Exception as e:
            sys.exit(f'FAILED {i}/{len(rows)} {name}: {e}\nAlready downloaded sources remain in work_original_wavs for resume.')
        durations.append({'file':name,'text':r['text'],'duration_seconds':f'{duration:.3f}'})
        print(f'[{i:03d}/{len(rows)}] {name}: {duration:.2f}s', flush=True)
    with (ROOT/'phrases.tsv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f, fieldnames=['file','text','duration_seconds'], delimiter='\t',lineterminator='\n')
        w.writeheader(); w.writerows(durations)
    guide=(ROOT/'README_FOR_CLAUDE.md').read_text(encoding='utf-8')
    with zipfile.ZipFile(OUTPUT_ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(OUTPUT.glob('*.wav')):
            z.write(p, 'Game_Assets/Audio/'+p.name)
        z.write(ROOT/'phrases.tsv','documentation/phrases.tsv')
        z.writestr('documentation/README_FOR_CLAUDE.md',guide)
    with zipfile.ZipFile(OUTPUT_ZIP) as z:
        bad=z.testzip()
        audio=[x for x in z.namelist() if x.endswith('.wav')]
        if bad or len(audio)!=109: raise RuntimeError('ZIP validation failed')
    print(f'\nCOMPLETE: {OUTPUT_ZIP} — {len(audio)} WAV files')

if __name__ == '__main__': main()
