LERNZEIT ASSET PACK v0.1
Attach this ZIP together with Lernzeit_Claude_Development_Brief_v0_1.pdf to Claude.
The files are design assets; some PNGs contain baked-in German labels. For de/ru translation rebuild text as UI elements.
Folders: assets/home, assets/progress, assets/settings, assets/parents, references.
See the PDF for functional requirements.
