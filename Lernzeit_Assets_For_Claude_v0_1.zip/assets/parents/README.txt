LERNZEIT — PARENTS / ELTERNBEREICH UI ASSETS

Icons/: 9 standalone transparent PNG illustrations on uniform 768x768 canvases.
Buttons/: 8 standalone transparent PNG buttons with German text embedded in the artwork.

Buttons are visual assets only: use real Godot Button or TextureButton nodes and create D-pad focus navigation and click actions.
For Russian/Deutsch interface switching, text-bearing buttons need text-free textures with dynamic Godot labels, or separately localized art.
In particular, do not make a cloud backup button functional without implementing actual storage/backup.
Atlas art source is smaller than 4K; outputs use resizing for practical UI use and are NOT native 4K art.

All PNGs have an alpha channel. A faint soft glow is intentionally preserved around sprites.
