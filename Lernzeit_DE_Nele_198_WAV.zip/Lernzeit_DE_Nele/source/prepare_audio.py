import json, pathlib, urllib.request, concurrent.futures, wave, numpy as np
root=pathlib.Path(__file__).parent
out=root/'Lernzeit_DE_Nele'
out.mkdir(exist_ok=True)
raw=root/'original_pcm'
raw.mkdir(exist_ok=True)
def process(item):
    dst=out/(item['name']+'.wav')
    if dst.exists(): return
    src=raw/(item['name']+'.pcm')
    if not src.exists():
        with urllib.request.urlopen(item['audio_url'],timeout=45) as r: src.write_bytes(r.read())
    x=np.frombuffer(src.read_bytes(),dtype='<i2').astype(np.float64)
    assert len(x)>100 and abs(len(x)/44100-item['duration'])<0.1
    active=np.where(np.abs(x)>100)[0]
    if not len(active): raise ValueError('silent '+item['name'])
    x=x[max(0,active[0]-882):min(len(x),active[-1]+1324)]
    rms=np.sqrt(np.mean(x*x))
    gain=min(32767*10**(-20/20)/rms, 29204/np.max(np.abs(x)))
    x=np.clip(x*gain,-32767,32767).astype('<i2')
    with wave.open(str(dst),'wb') as w:
        w.setparams((1,2,44100,0,'NONE','not compressed'));w.writeframes(x.tobytes())
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    list(pool.map(process,json.loads((root/'speech_results.json').read_text())))
print('WAV files:',len(list(out.glob('*.wav'))))
